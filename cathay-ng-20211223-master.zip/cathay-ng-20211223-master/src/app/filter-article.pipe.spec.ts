import { FilterArticlePipe } from './filter-article.pipe';

describe('FilterArticlePipe', () => {
  it('create an instance', () => {
    const pipe = new FilterArticlePipe();
    expect(pipe).toBeTruthy();
  });
});
