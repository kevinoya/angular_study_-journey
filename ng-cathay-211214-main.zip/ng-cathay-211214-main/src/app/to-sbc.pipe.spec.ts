import { ToSbcPipe } from './to-sbc.pipe';

describe('ToSbcPipe', () => {
  it('create an instance', () => {
    const pipe = new ToSbcPipe();
    expect(pipe).toBeTruthy();
  });
});
