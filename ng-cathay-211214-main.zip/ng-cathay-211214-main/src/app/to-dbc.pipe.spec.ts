import { ToDbcPipe } from './to-dbc.pipe';

describe('ToDbcPipe', () => {
  it('create an instance', () => {
    const pipe = new ToDbcPipe();
    expect(pipe).toBeTruthy();
  });
});
